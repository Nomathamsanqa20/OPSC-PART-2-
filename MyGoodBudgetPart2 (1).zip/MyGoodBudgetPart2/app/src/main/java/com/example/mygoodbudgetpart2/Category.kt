package com.example.mygoodbudgetpart2


data class Category(
    val id: Long,
    val name: String,
    val userId: Long
)